import java.util.Scanner;

public class HotelReservation {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Welcome to the Hotel Reservation System!");
        System.out.println("Enter the number of rooms you would like to reserve:");
        int numRooms = input.nextInt();

        int[] rooms = new int[numRooms];
        for (int i = 0; i < numRooms; i++) {
            System.out.println("Enter the number of guests for room " + (i+1) + ":");
            rooms[i] = input.nextInt();
        }

        int totalGuests = 0;
        for (int numGuests : rooms) {
            totalGuests += numGuests;
        }

        System.out.println("You have reserved " + numRooms + " rooms for a total of " + totalGuests + " guests.");
    }
}
